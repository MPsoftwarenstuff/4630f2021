package com.example.a3_secondphaseofapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Resume : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resume)


    }


}